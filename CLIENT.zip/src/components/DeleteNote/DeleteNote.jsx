
const DeleteNote = () => {


    return (
    
)


}
export default DeleteNote