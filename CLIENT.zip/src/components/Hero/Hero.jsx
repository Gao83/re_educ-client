import './Hero.css'
const Hero = () => {

    return (
        <div className="hero-home">
            <h1>HERO</h1>
        </div>
    )

}

export default Hero
