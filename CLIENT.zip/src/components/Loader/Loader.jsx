import { Spinner } from "react-bootstrap"

const Loader = () => {

    <Spinner animation="grow" />

}
export default Loader